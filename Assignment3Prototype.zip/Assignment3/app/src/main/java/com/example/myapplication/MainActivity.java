package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity
{
    private EditText idField;
    private TextView idLabel;
    private EditText nameField;
    private TextView nameLabel;
    private EditText emailField;
    private TextView emailLabel;
    private EditText code1Field;
    private TextView code1Label;
    private EditText code2Field;
    private TextView code2Label;
    private TextView breedLabel;
    private Spinner mySpinner;
    Cursor mCursor;

    private View.OnClickListener submitListener =  new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            boolean pass = true;
            boolean verified = false;
            int emailResult, idResult;
            String id = idField.getText().toString();
            String name = nameField.getText().toString();
            String email = emailField.getText().toString();
            String gender = "";
            String code1 = code1Field.getText().toString();
            String code2 = code2Field.getText().toString();
            String breed = mySpinner.getSelectedItem().toString();
            String neutered;
            String message = "";

            CheckBox checkBox = findViewById(R.id.checkBox);
            if (checkBox.isChecked())
                neutered = "YES";
            else
                neutered = "NO";

            RadioButton radioButton1 = findViewById(R.id.radioButton10);
            RadioButton radioButton2 = findViewById(R.id.radioButton11);
            if (radioButton1.isChecked())
                gender = "MALE";
            else if (radioButton2.isChecked())
                gender = "FEMALE";

            if (checkComplete()) // If any field is not filled out
            {
                pass = false;
                if (name.isEmpty())
                    nameLabel.setTextColor(getResources().getColor(R.color.incorrect));
                if (id.isEmpty())
                    idLabel.setTextColor(getResources().getColor(R.color.incorrect));
                if (email.isEmpty())
                    emailLabel.setTextColor(getResources().getColor(R.color.incorrect));
                if (code1.isEmpty())
                    code1Label.setTextColor(getResources().getColor(R.color.incorrect));
                if (code2.isEmpty())
                    code2Label.setTextColor(getResources().getColor(R.color.incorrect));
                if (breed.contains("---"))
                    breedLabel.setTextColor(getResources().getColor(R.color.incorrect));
            }
            else
            {
                nameLabel.setTextColor(getResources().getColor(R.color.black));
                idLabel.setTextColor(getResources().getColor(R.color.black));
                emailLabel.setTextColor(getResources().getColor(R.color.black));
                code1Label.setTextColor(getResources().getColor(R.color.black));
                code2Label.setTextColor(getResources().getColor(R.color.black));
                breedLabel.setTextColor(getResources().getColor(R.color.black));
            }
            if (!checkCodes()) // Check if access codes match
            {
                pass = false;
                code1Label.setTextColor(getResources().getColor(R.color.incorrect));
                code2Label.setTextColor(getResources().getColor(R.color.incorrect));
            }
            else
            {
                code1Label.setTextColor(getResources().getColor(R.color.black));
                code2Label.setTextColor(getResources().getColor(R.color.black));
            }

            emailResult = checkEmail();

            switch (emailResult)
            {
                case 1:     // Prefix was too short
                case 2:     // Domain name was invalid
                case 3:     // Both 1 and 2
                case 4:     // Email format was incorrect
                {
                    pass = false;
                    emailLabel.setTextColor(getResources().getColor(R.color.incorrect));
                    break;
                }
                default:    // No errors
                {
                    emailLabel.setTextColor(getResources().getColor(R.color.black));
                    break;
                }
            }

            idResult = checkID();

            switch (idResult)
            {
                case 1:             // ID length not between 5 - 15
                case 2:             // Non alphanumeric characters detected
                case 3:             // Both 1 and 2
                case 4:             // ID matches one in the database
                {
                    pass = false;
                    idLabel.setTextColor(getResources().getColor(R.color.incorrect));
                    break;
                }
                default:            // No errors
                {
                    idLabel.setTextColor(getResources().getColor(R.color.black));
                    break;
                }
            }

            if (pass)
            {
                // Add the info to database and alert user that this has been done with a toast
                ContentValues mNewValues = new ContentValues();
                mNewValues.put(MySuperCoolContentProvider.COLUMN_NAME, name.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_ID, id.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_GENDER, gender.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_EMAIL, email.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_CODE, code1.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_BREED, breed.trim());
                mNewValues.put(MySuperCoolContentProvider.COLUMN_NEUTERED, neutered.trim());
                getContentResolver().insert(MySuperCoolContentProvider.CONTENT_URI, mNewValues);
                message = "Your information has been added to the database...";
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
            else
            {
                // Display error message using an alert dialog
                DialogueFragment f = new DialogueFragment();
                f.show(getSupportFragmentManager(), "Dialog");
            }

        }
    };

    public void reset(View v)
    {
        idField.setText("Id");
        nameField.setText("");
        RadioButton radioButton1 = findViewById(R.id.radioButton10);
        RadioButton radioButton2 = findViewById(R.id.radioButton11);
        radioButton1.setChecked(false);
        radioButton2.setChecked(true);
        emailField.setText("none@none.com");
        code1Field.setText("");
        code2Field.setText("");
        mySpinner.setSelection(0);
        CheckBox checkBox = findViewById(R.id.checkBox);
        checkBox.setChecked(true);
        nameLabel.setTextColor(getResources().getColor(R.color.black));
        idLabel.setTextColor(getResources().getColor(R.color.black));
        emailLabel.setTextColor(getResources().getColor(R.color.black));
        code1Label.setTextColor(getResources().getColor(R.color.black));
        code2Label.setTextColor(getResources().getColor(R.color.black));
        breedLabel.setTextColor(getResources().getColor(R.color.black));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.constraint);
        idField = findViewById(R.id.microchipID);
        idLabel = findViewById(R.id.idLabel);
        nameField = findViewById(R.id.name_field);
        nameLabel = findViewById(R.id.namelabel);
        emailField = findViewById(R.id.emailField);
        emailLabel = findViewById(R.id.emailLabel);
        code1Field = findViewById(R.id.code_1);
        code1Label = findViewById(R.id.code1Label);
        code2Field = findViewById(R.id.code_2);
        code2Label = findViewById(R.id.code2Label);
        breedLabel = findViewById(R.id.breedLabel);
        Button submitbutton = findViewById(R.id.Submit_button);
        submitbutton.setOnClickListener(submitListener);
        RadioButton radioButton2 = findViewById(R.id.radioButton11);
        radioButton2.setChecked(true);
        CheckBox checkBox = findViewById(R.id.checkBox);
        checkBox.setChecked(true);
        setSpinner();
        mySpinner.setSelection(0);

    }


    private void setSpinner()
    {
        mySpinner = findViewById(R.id.role_spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.breeds, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);
    }

    // Check to see if any entry is incomplete
    private boolean checkComplete()
    {
        String id = idField.getText().toString();
        String name = nameField.getText().toString();
        String email = emailField.getText().toString();
        String code1 = code1Field.getText().toString();
        String code2 = code2Field.getText().toString();
        String breed = mySpinner.getSelectedItem().toString();
        return (name.isEmpty() || id.isEmpty() || email.isEmpty() || code1.isEmpty() || code2.isEmpty() || breed.contains("---"));
    }

    // This checks the microchip ID field to make sure all is well
    // It will return a number 0 - 4 representing different outcomes
    // 0 - no issues
    // 1 - Not 5 - 15 characters
    // 2 - Non alphanumeric characters detected
    // 3 - Both 1 & 2
    // 4 - The ID matches one in the database
    private int checkID()
    {
        int result = 0;
        String id = idField.getText().toString();

        if ((id.length() < 5 || id.length() > 15) && !id.matches("^[a-zA-Z0-9]*$"))
        {
            result = 3;
        }
        else if (id.length() < 5 || id.length() > 15)
        {
            result = 1;
        }
        else if (!id.matches("^[a-zA-Z0-9]*$"))
        {
            result = 2;
        }
        // Here is where the database should be searched
        mCursor = getContentResolver().query(MySuperCoolContentProvider.CONTENT_URI, null, null, null, null);

        return result;
    }

    // This checks the email field to make sure the formatting is correct
    // It will return a number 0 - 4 representing different outcomes
    // 0 - no issues
    // 1 - Prefix is too short
    // 2 - Invalid domain name used
    // 3 - Both 1 & 2
    // 4 - Invalid format for email (no '@' or '.' also if '.' appears before '@')
    private int checkEmail()
    {
        int result = 0;
        String email = emailField.getText().toString();
        int index1 = email.indexOf("@");
        int index2 = email.indexOf(".");
        String prefix = email.substring(0, index1);
        String domain_type = email.substring(index2);

        if ((!email.contains("@") || !email.contains(".")) || index2 < index1)
        {
            result = 4;
        }
        else if (prefix.length() < 3 && (!domain_type.contains("edu") && !domain_type.contains("com") && !domain_type.contains("co") && !domain_type.contains("gal")))
        {
            result = 3;
        }
        else if (!domain_type.contains("edu") && !domain_type.contains("com") && !domain_type.contains("co") && !domain_type.contains("gal"))
        {
            result = 2;
        }
        else if (prefix.length() < 3)
        {
            result = 1;
        }

        return result;
    }

    // This checks to make sure the access codes match
    private boolean checkCodes()
    {
        String code1 = code1Field.getText().toString();
        String code2 = code2Field.getText().toString();
        return (code1.equals(code2));
    }

    // This returns a string listing all known errors with user submission
    public String messageError()
    {
        String message = "";
        int emailResult = checkEmail();
        int idResult = checkID();

        if (checkComplete())
            message = "Incomplete form\n";
        if (!checkCodes())
            message += "Access codes don't match\n";
        switch (emailResult)
        {
            case 1:     // Prefix was too short
            {
                message += "Email prefix is too short\n";
                break;
            }
            case 2:     // Domain name was invalid
            {
                message += "Email domain name is invalid\n";
                break;
            }
            case 3:     // Both 1 and 2
            {
                message += "Email prefix is too short\nEmail domain name is invalid\n";
                break;
            }
            case 4:     // Email format was incorrect
            {
                message += "Email address not formatted properly\n";
                break;
            }
            default:    // No errors
            {
                break;
            }
        }
        switch (idResult)
        {
            case 1:             // ID length not between 5 - 15
            {
                message += "ID length not between 5 - 15 characters\n";
                break;
            }
            case 2:             // Non alphanumeric characters detected
            {
                message += "ID can't contain alphanumeric characters\n";
                break;
            }
            case 3:             // Both 1 and 2
            {
                message += "ID must be between 5 - 15 characters and can't contain alphanumeric characters\n";
                break;
            }
            case 4:             // ID matches one in the database
            {
                message += "ID matches an ID in the database\n";
                break;
            }
            default:            // No errors
            {
                break;
            }
        }

        return message;
    }
}
