package com.example.realassignment4;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class AddQuestionActivity extends AppCompatActivity {

    private EditText questionEntry;
    private TextView questionLabel;

    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("server/saving-data/fireblog");

    private View.OnClickListener cancelListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {
            openAskQuestionActivity();
        }
    };

    private View.OnClickListener addListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {
            addQuestion();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);

        questionEntry = findViewById(R.id.questionEntry);
        questionLabel = findViewById(R.id.textView);
        ImageButton cancel = findViewById(R.id.cancelButton);
        Button addQ = findViewById(R.id.addQbutton);

        cancel.setOnClickListener(cancelListener);
        addQ.setOnClickListener(addListener);
    }

    public void openAskQuestionActivity() {
        Intent intent = new Intent(this, AskQuestionActivity.class);
        startActivity(intent);
    }

    public void addQuestion()
    {
        final boolean[] success = {true};
        String question = questionEntry.getText().toString();
        String buffer = question;

        if (question.matches(""))
        {
            success[0] = false;
            Toast.makeText(this, "Nothing was entered...", Toast.LENGTH_LONG).show();
        }
        else if (buffer.replace(" ", "").length() > 120)
        {
            success[0] = false;
            Toast.makeText(this, "Your question is too long!", Toast.LENGTH_LONG).show();
        }
        ref.orderByChild("questions").equalTo(question).limitToFirst(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                success[0] = false;
                Toast.makeText(AddQuestionActivity.this, "This question is already in the database...", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        if (success[0])
        {
            questionLabel.setTextColor(getResources().getColor(R.color.black));
            Toast.makeText(this, "Your question was added :)", Toast.LENGTH_LONG).show();
            DatabaseReference questionRef = ref.child("questions");

            Map<String, Object> questionUpdate = new HashMap<>();
            questionUpdate.put(question, "?");
            questionRef.updateChildren(questionUpdate);

            questionEntry.setText("");
        }
        else
        {
            questionLabel.setTextColor(getResources().getColor(R.color.incorrect));
        }
    }
}
