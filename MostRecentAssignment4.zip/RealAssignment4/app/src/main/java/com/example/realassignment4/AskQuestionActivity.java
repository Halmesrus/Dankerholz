package com.example.realassignment4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AskQuestionActivity extends AppCompatActivity {

    private TextView questionDisplay;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("server/saving-data/fireblog");

    private View.OnClickListener askListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {
            ref.orderByChild("questions").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot questionSnapshot: dataSnapshot.getChildren()) {
                        questionDisplay.setText(questionSnapshot.child("questions").getKey());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    };

    private View.OnClickListener addListener = new View.OnClickListener() {
      @Override
      public void onClick(View view)
      {
            openAddQuestionActivity();
      }
    };

    public void clear(View v)
    {
        questionDisplay.setText("");
    }

    public void signOut(View v)
    {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_question);

        questionDisplay = findViewById(R.id.questionDisplay);
        ImageButton askButton = findViewById(R.id.askButton);
        ImageButton addButton = findViewById(R.id.addButton);

        askButton.setOnClickListener(askListener);
        addButton.setOnClickListener(addListener);

    }

    public void openAddQuestionActivity() {
        Intent intent = new Intent(this, AddQuestionActivity.class);
        startActivity(intent);
    }
}