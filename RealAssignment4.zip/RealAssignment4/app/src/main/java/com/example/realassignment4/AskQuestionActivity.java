package com.example.realassignment4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class AskQuestionActivity extends AppCompatActivity {

    private TextView questionDisplay;

    private FirebaseAuth mAuth;

    private View.OnClickListener askListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {

        }
    };

    private View.OnClickListener addListener = new View.OnClickListener() {
      @Override
      public void onClick(View view)
      {
            openAddQuestionActivity();
      }
    };

    public void clear(View v)
    {
        questionDisplay.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_question);

        questionDisplay = findViewById(R.id.questionDisplay);
        ImageButton askButton = findViewById(R.id.askButton);
        ImageButton addButton = findViewById(R.id.addButton);

        askButton.setOnClickListener(askListener);
        addButton.setOnClickListener(addListener);

    }

    public void openAddQuestionActivity() {
        Intent intent = new Intent(this, AddQuestionActivity.class);
        startActivity(intent);
    }
}