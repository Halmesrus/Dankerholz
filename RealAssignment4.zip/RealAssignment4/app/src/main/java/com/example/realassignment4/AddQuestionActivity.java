package com.example.realassignment4;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

public class AddQuestionActivity extends AppCompatActivity {

    private EditText questionEntry;

    private View.OnClickListener cancelListener = new View.OnClickListener() {
        @Override
        public void onClick(View view)
        {
            openAskQuestionActivity();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);

        questionEntry = findViewById(R.id.questionEntry);
        ImageButton cancel = findViewById(R.id.cancelButton);

        cancel.setOnClickListener(cancelListener);
    }

    public void openAskQuestionActivity() {
        Intent intent = new Intent(this, AskQuestionActivity.class);
        startActivity(intent);
    }
}
