package com.example.myapplication;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

public class MySuperCoolContentProvider extends ContentProvider {

    protected static final class MainDatabaseHelper extends SQLiteOpenHelper
    {
        MainDatabaseHelper (Context context)
        {
            super(context, DBNAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL(SQL_CREATE_MAIN);
        }

        @Override
        public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
        }
    }

    public final static String DBNAME = "Super_cool_database";

    public final static String SQL_CREATE_MAIN = "CREATE TABLE " + DBNAME + " ( " + "_ID INTEGER PRIMARY KEY, " + "Name TEXT, " + "MicrochipID TEXT, " + "Gender TEXT, " + "Email TEXT, " + "Code TEXT, " + "Breed TEXT, " + "Neutered TEXT)";

    public static final Uri CONTENT_URI = Uri.parse("content://com.example.myapplication.provider");

    public final static String COLUMN_NAME = "Name";
    public final static String COLUMN_ID = "MicrochipID";
    public final static String COLUMN_GENDER = "Gender";
    public final static String COLUMN_EMAIL = "Email";
    public final static String COLUMN_CODE  = "Code";
    public final static String COLUMN_BREED = "Breed";
    public final static String COLUMN_NEUTERED = "Neutered";

    private MainDatabaseHelper mOpenHelper;

    public MySuperCoolContentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return mOpenHelper.getWritableDatabase().delete(DBNAME, selection, selectionArgs);
    }

    @Override
    public String getType(Uri uri) {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        String name = values.getAsString("Name");
        String microchipID = values.getAsString("MicrochipID");
        String gender = values.getAsString("Gender");
        String email = values.getAsString("Email");
        String code = values.getAsString("Code");
        String breed = values.getAsString("Breed");
        String neutered = values.getAsString("Neutered");

        if (name.equals(""))
            return null;
        if (microchipID.equals(""))
            return null;
        if (gender.equals(""))
            return null;
        if (email.equals(""))
            return null;
        if (code.equals(""))
            return null;
        if (breed.equals(""))
            return null;
        if (neutered.equals(""))
            return null;

        long id = mOpenHelper.getWritableDatabase().insert(DBNAME, null, values);

        return Uri.withAppendedPath(CONTENT_URI, "" + id);
    }

    @Override
    public boolean onCreate() {
        mOpenHelper = new MainDatabaseHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        return mOpenHelper.getReadableDatabase().query(DBNAME, projection, selection, selectionArgs, null, null, sortOrder);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
